package com.pds.ing2.backendpds2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendPds2Application {

	public static void main(String[] args) {
		SpringApplication.run(BackendPds2Application.class, args);
	}

}
